# SCIENCE PATH AI — starter website

A responsive React + Vite prototype for the Science Path AI career-fair experience.

## Included

- Responsive desktop, tablet and mobile layout
- Explorer profile onboarding (local browser demo)
- Home dashboard and ten learning-lab categories
- Generic educational simulation screen with topic selection and animation
- Quiz Arena with scoring and explanations
- Career Navigator and external official-resource links
- Progress checklist stored in browser local storage
- Floating SCIENCE PATH AI Companion with curated demonstration responses
- Browser speech playback where supported
- Dark appearance and large-text controls
- Reduced-motion and high-contrast CSS support

## Requirements

- Node.js 18 or later
- npm
- A modern browser

## Run locally

1. Extract the ZIP.
2. Open a terminal in the `science-path-ai` folder.
3. Run:

```bash
npm install
npm run dev
```

4. Open the local URL printed by Vite (normally http://localhost:5173).

To create a production build:

```bash
npm run build
npm run preview
```

## Important prototype limitations

This is a working front-end prototype, not a production account platform.

- The profile form does not create a secure account. It stores non-sensitive demo profile data in localStorage on the current browser/device.
- There is no server database, cross-device sync, email verification, password reset or secure login yet.
- The floating AI uses a small curated response library. It is not a live generative AI model.
- The simulation visuals are educational placeholders, not validated physics engines or real scientific observations.
- The language selector is a profile preference demo. Full reviewed translations and multilingual speech have not yet been implemented.
- The included CSS supports accessibility preferences, but a full accessibility audit and testing with assistive technology are still required.

Before public deployment, integrate a secure authentication/backend service, add privacy and consent flows suitable for children, review all educational content with reliable sources, implement real simulations, and test every device and language. Never put private API keys in frontend source code.

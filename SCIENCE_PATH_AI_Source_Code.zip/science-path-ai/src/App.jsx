import React, { useEffect, useMemo, useState } from "react";
import {
  Atom, BookOpen, ChevronRight, CircleHelp, Compass, GraduationCap,
  Languages, LogOut, Menu, Moon, Search, Settings, ShieldCheck,
  Sparkles, Sun, Telescope, UserRound, Volume2, X, Send, Mic,
  Rocket, Award, House, ChartNoAxesCombined, Play, CheckCircle2
} from "lucide-react";
import { modules, careers, questions, languageNames } from "./data.js";

const starterProfile = { name:"Explorer", aim:"Future Scientist", classLevel:"Grade 5", country:"India", language:"English" };
const readProfile = () => {
  try { return JSON.parse(localStorage.getItem("spa-profile")) || null; } catch { return null; }
};

function App() {
  const [profile, setProfile] = useState(readProfile);
  const [page, setPage] = useState("home");
  const [activeModule, setActiveModule] = useState(modules[0]);
  const [chatOpen, setChatOpen] = useState(false);
  const [chatInput, setChatInput] = useState("");
  const [messages, setMessages] = useState([{ role:"ai", text:"Hello, Explorer! I'm your SCIENCE PATH AI Companion. Ask me about space, science or your current mission." }]);
  const [dark, setDark] = useState(false);
  const [largeText, setLargeText] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [quizIndex, setQuizIndex] = useState(0);
  const [selected, setSelected] = useState(null);
  const [score, setScore] = useState(0);
  const [quizDone, setQuizDone] = useState(false);
  const [completed, setCompleted] = useState(() => JSON.parse(localStorage.getItem("spa-completed") || "[]"));

  useEffect(() => { document.documentElement.dataset.theme = dark ? "dark" : "light"; }, [dark]);
  useEffect(() => { document.documentElement.classList.toggle("large-text", largeText); }, [largeText]);
  useEffect(() => { localStorage.setItem("spa-completed", JSON.stringify(completed)); }, [completed]);

  const filteredModules = useMemo(() => modules.filter(m =>
    `${m.title} ${m.category} ${m.description}`.toLowerCase().includes(query.toLowerCase())
  ), [query]);

  function saveProfile(e) {
    e.preventDefault();
    const form = new FormData(e.currentTarget);
    const p = {
      name: String(form.get("name")).trim(),
      aim: String(form.get("aim")).trim(),
      classLevel: String(form.get("classLevel")),
      country: String(form.get("country")).trim() || "India",
      language: String(form.get("language"))
    };
    localStorage.setItem("spa-profile", JSON.stringify(p));
    setProfile(p);
  }

  function logout() {
    localStorage.removeItem("spa-profile");
    setProfile(null);
    setPage("home");
  }

  function answerAI(text) {
    const t = text.toLowerCase();
    if (t.includes("black hole")) return "A black hole is a region of space where gravity is so strong that, beyond its event horizon, light cannot escape. Our visual model is simplified; it is not a live observation.";
    if (t.includes("isro") || t.includes("chandrayaan")) return "ISRO is India's space agency. Chandrayaan is India's lunar exploration programme. You can explore the Indian Space Research Lab for mission learning.";
    if (t.includes("planet") || t.includes("solar")) return "Our Solar System has eight recognised planets orbiting the Sun. Planets also rotate, and many have moons. Open the Solar System Lab to explore these ideas.";
    if (t.includes("career") || t.includes("job")) return "Science connects to many careers, including astronomer, aerospace engineer, astrophysicist, satellite engineer and science communicator. Visit Career Navigator to explore them.";
    if (t.includes("star")) return "Stars form in clouds of gas and dust. They spend much of their lives in a stable phase called the main sequence. Their later evolution depends largely on their mass.";
    return "Great question! I can help with astronomy, space technology, science careers and the learning modules on this website. Try asking about planets, stars, black holes or ISRO. This free demo uses a curated response library, not a live generative AI service.";
  }

  function sendMessage(e) {
    e.preventDefault();
    const text = chatInput.trim();
    if (!text) return;
    setMessages(prev => [...prev, { role:"user", text }, { role:"ai", text:answerAI(text) }]);
    setChatInput("");
  }

  function speak(text) {
    if ("speechSynthesis" in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = profile?.language === "தமிழ்" ? "ta-IN" : "en-IN";
      window.speechSynthesis.speak(utterance);
    } else {
      alert("Speech playback is not supported in this browser.");
    }
  }

  function openModule(m) { setActiveModule(m); setPage("simulation"); }
  function markComplete() {
    if (!completed.includes(activeModule.id)) setCompleted(prev => [...prev, activeModule.id]);
  }
  function chooseAnswer(i) {
    if (selected !== null) return;
    setSelected(i);
    if (i === questions[quizIndex].answer) setScore(s => s + 1);
  }
  function nextQuestion() {
    if (quizIndex === questions.length - 1) setQuizDone(true);
    else { setQuizIndex(i => i + 1); setSelected(null); }
  }
  function resetQuiz() { setQuizIndex(0); setSelected(null); setScore(0); setQuizDone(false); }

  const navItems = [
    ["home","Home",House],["explore","Explore",Compass],["quiz","Quiz Arena",Award],
    ["careers","Career Navigator",GraduationCap],["progress","My Progress",ChartNoAxesCombined]
  ];

  if (!profile) return <div className="auth-shell">
    <div className="auth-art">
      <div className="brand light"><span className="brand-mark"><Atom /></span> SCIENCE PATH AI</div>
      <div className="auth-art-content">
        <span className="eyebrow">THE YOUNG EXPLORERS EXPERIENCE</span>
        <h1>Explore science.<br/>Discover your future.</h1>
        <p>A welcoming space to explore astronomy, science experiments and future careers.</p>
        <div className="orbit-art" aria-hidden="true"><div className="orbit orbit-one"></div><div className="orbit orbit-two"></div><div className="planet">🪐</div><span className="orbit-star">✦</span></div>
      </div>
      <p className="auth-foot">Learn at your pace. Curiosity belongs to everyone.</p>
    </div>
    <div className="auth-form-wrap">
      <form className="auth-form" onSubmit={saveProfile}>
        <span className="eyebrow">WELCOME, EXPLORER</span>
        <h2>Create your explorer profile</h2>
        <p className="muted">This demonstration stores profile details only in this browser on this device.</p>
        <label>Full name<input name="name" placeholder="Enter your name" required maxLength="70"/></label>
        <label>Your career aim<input name="aim" placeholder="e.g. Aerospace Engineer" required maxLength="80"/></label>
        <label>Class / educational level<select name="classLevel" defaultValue="Grade 5"><option>Grade 5</option><option>Grade 6</option><option>Grade 7</option><option>Grade 8</option><option>Grade 9</option><option>Grade 10</option><option>Grade 11</option><option>Grade 12</option><option>College</option><option>Teacher / Parent</option></select></label>
        <label>Country<input name="country" defaultValue="India" maxLength="60"/></label>
        <label>Preferred language<select name="language">{languageNames.map(l=><option key={l}>{l}</option>)}</select></label>
        <button className="btn primary full" type="submit">Enter SCIENCE PATH AI <ChevronRight size={18}/></button>
        <p className="tiny muted">Prototype notice: this is not secure account authentication. Do not enter passwords or sensitive personal information.</p>
      </form>
    </div>
  </div>;

  const identity = `${profile.name.toUpperCase()} – ${profile.aim.toUpperCase()}`;

  return <div className="app-shell">
    <aside className={`sidebar ${menuOpen ? "show" : ""}`}>
      <div className="brand"><span className="brand-mark"><Atom/></span><span>SCIENCE PATH <b>AI</b></span></div>
      <div className="side-label">WORKSPACE</div>
      <nav>{navItems.map(([id,label,Icon])=><button key={id} className={`nav-item ${page===id || (id==="explore" && page==="simulation") ? "active":""}`} onClick={()=>{setPage(id);setMenuOpen(false);}}><Icon size={19}/><span>{label}</span></button>)}</nav>
      <div className="sidebar-bottom">
        <div className="mini-profile"><div className="avatar">{profile.name.charAt(0).toUpperCase()}</div><div><b>{profile.name}</b><small>{profile.aim}</small></div></div>
        <button className="nav-item" onClick={()=>setPage("settings")}><Settings size={18}/>Settings</button>
        <button className="nav-item" onClick={logout}><LogOut size={18}/>Log out</button>
      </div>
    </aside>

    <main className="main-area">
      <header className="topbar">
        <button className="icon-button mobile-menu" aria-label="Open navigation" onClick={()=>setMenuOpen(!menuOpen)}><Menu/></button>
        <div className="breadcrumb">SCIENCE PATH AI <ChevronRight size={14}/> <span>{page==="simulation" ? activeModule.title : page.replace("-", " ")}</span></div>
        <div className="top-actions">
          <button className="icon-button" aria-label="Toggle dark mode" onClick={()=>setDark(!dark)}>{dark?<Sun size={18}/>:<Moon size={18}/>}</button>
          <button className="icon-button" aria-label="Increase text size" onClick={()=>setLargeText(!largeText)}>Aa</button>
          <span className="top-avatar">{profile.name.charAt(0).toUpperCase()}</span>
        </div>
      </header>

      <div className="page-content">
        {page==="home" && <Home identity={identity} completed={completed} openModule={openModule} setPage={setPage}/>}
        {page==="explore" && <Explore query={query} setQuery={setQuery} filteredModules={filteredModules} openModule={openModule} completed={completed}/>}
        {page==="simulation" && <Simulation module={activeModule} markComplete={markComplete} completed={completed} askAI={()=>setChatOpen(true)} speak={speak}/>}
        {page==="quiz" && <Quiz quizIndex={quizIndex} selected={selected} score={score} quizDone={quizDone} chooseAnswer={chooseAnswer} nextQuestion={nextQuestion} resetQuiz={resetQuiz}/>}
        {page==="careers" && <Careers/>}
        {page==="progress" && <Progress completed={completed} setPage={setPage}/>}
        {page==="settings" && <SettingsPage profile={profile} setDark={setDark} dark={dark} largeText={largeText} setLargeText={setLargeText} logout={logout}/>}
      </div>
      <footer className="footer"><span>© 2026 SCIENCE PATH AI</span><span>Curiosity has no limits.</span></footer>
    </main>

    <div className="floating-ai">
      {chatOpen && <section className="ai-panel" aria-label="SCIENCE PATH AI Companion">
        <div className="ai-head"><div className="ai-avatar"><Sparkles/></div><div><b>SCIENCE PATH AI</b><small>Science companion · Demo mode</small></div><button className="ai-close" aria-label="Close assistant" onClick={()=>setChatOpen(false)}><X size={19}/></button></div>
        <div className="ai-context">Helping {profile.name} explore {page==="simulation"?activeModule.title:"science and discovery"}</div>
        <div className="ai-chat" aria-live="polite">{messages.map((m,i)=><div key={i} className={`chat-bubble ${m.role}`}>{m.text}{m.role==="ai"&&<button className="speak-button" onClick={()=>speak(m.text)} aria-label="Read answer aloud"><Volume2 size={15}/></button>}</div>)}</div>
        <form className="ai-compose" onSubmit={sendMessage}><input value={chatInput} onChange={e=>setChatInput(e.target.value)} placeholder="Ask a science question…" aria-label="Your question"/><button className="send-btn" aria-label="Send message"><Send size={18}/></button></form>
        <p className="ai-disclaimer">Curated demo answers. Verify important facts with trusted science sources.</p>
      </section>}
      <button className="ai-launcher" onClick={()=>setChatOpen(!chatOpen)} aria-label={chatOpen?"Close AI companion":"Open AI companion"}><span className="ai-orb"><Sparkles size={25}/></span><span className="ai-launch-label">Ask AI</span></button>
    </div>
  </div>;
}

function Home({identity,completed,openModule,setPage}) {
  return <div className="stack">
    <section className="welcome-banner">
      <div className="welcome-copy"><span className="eyebrow light-eyebrow">YOUR DISCOVERY JOURNEY STARTS HERE</span><h1>Hello, Explorer!</h1><p className="identity">{identity}</p><p>Choose a mission, ask questions and discover how science connects to the world around you.</p><button className="btn white-btn" onClick={()=>setPage("explore")}>Explore learning labs <ChevronRight size={18}/></button></div>
      <div className="welcome-visual" aria-hidden="true"><div className="planet-big">🪐</div><span className="visual-star s1">✦</span><span className="visual-star s2">✧</span><span className="visual-star s3">✦</span></div>
    </section>
    <section className="stats-row">
      <Stat icon={<Telescope/>} label="Learning labs" value="10"/>
      <Stat icon={<CheckCircle2/>} label="Labs completed" value={completed.length}/>
      <Stat icon={<Award/>} label="Learning level" value={completed.length>5?"Explorer Pro":"Explorer"}/>
    </section>
    <div className="section-heading"><div><span className="eyebrow">START EXPLORING</span><h2>Choose your discovery</h2><p className="muted">Interactive learning spaces for curious minds.</p></div><button className="text-button" onClick={()=>setPage("explore")}>View all labs <ChevronRight size={16}/></button></div>
    <div className="module-grid">{modules.slice(0,4).map(m=><ModuleCard key={m.id} module={m} openModule={openModule} completed={completed}/>)}</div>
    <section className="callout"><div className="callout-icon"><Sparkles/></div><div><b>Curious about something?</b><p>Open your floating AI scientist and ask a question in your own words.</p></div></section>
  </div>;
}
function Stat({icon,label,value}) { return <div className="stat-card"><div className="stat-icon">{icon}</div><div><strong>{value}</strong><small>{label}</small></div></div>; }

function ModuleCard({module,openModule,completed}) {
  return <article className="module-card"><div className="module-card-top"><span className="module-emoji">{module.icon}</span>{completed.includes(module.id)&&<span className="complete-pill"><CheckCircle2 size={13}/> Completed</span>}</div><span className="card-category">{module.category}</span><h3>{module.title}</h3><p>{module.description}</p><button className="card-link" onClick={()=>openModule(module)}>Open learning lab <ChevronRight size={16}/></button></article>;
}

function Explore({query,setQuery,filteredModules,openModule,completed}) {
  return <div className="stack"><PageHeading eyebrow="DISCOVERY LIBRARY" title="Explore science" description="Choose a learning lab and investigate the universe at your own pace."/><div className="search-box"><Search size={19}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search labs, topics or categories…" aria-label="Search learning labs"/></div><div className="module-grid">{filteredModules.map(m=><ModuleCard key={m.id} module={m} openModule={openModule} completed={completed}/>)}</div>{filteredModules.length===0&&<p className="empty-state">No labs match that search. Try another word.</p>}</div>;
}

function Simulation({module,markComplete,completed,askAI,speak}) {
  const [topic,setTopic] = useState(module.topics[0]);
  const [level,setLevel] = useState("Beginner");
  const [playing,setPlaying] = useState(false);
  useEffect(()=>{setTopic(module.topics[0]);setPlaying(false);},[module.id]);
  const explanation = `${topic} is an important idea in ${module.title}. Explore the visual model, change the available controls and observe how the model responds. This is a simplified educational representation, not a live scientific observation.`;
  return <div className="stack"><PageHeading eyebrow={module.category.toUpperCase()} title={module.title} description={module.description}/><div className="simulation-layout"><section className="sim-stage"><div className="sim-toolbar"><span>INTERACTIVE LEARNING MODEL</span><span className="model-tag">Simplified model</span></div><div className={`space-visual ${playing?"is-playing":""}`}><div className="space-glow"></div><div className="space-object">{module.icon}</div><div className="space-orbit one"></div><div className="space-orbit two"></div><div className="space-star a">✦</div><div className="space-star b">✧</div><div className="space-star c">✦</div><div className="visual-caption">{topic}</div></div><div className="sim-controls"><button className="btn primary" onClick={()=>setPlaying(!playing)}><Play size={16}/>{playing?"Pause animation":"Play animation"}</button><label className="level-select">Explanation level<select value={level} onChange={e=>setLevel(e.target.value)}><option>Beginner</option><option>Intermediate</option><option>Advanced</option></select></label></div></section><aside className="sim-side"><div className="panel"><span className="eyebrow">EXPLORE A TOPIC</span><h3>Choose your focus</h3>{module.topics.map(t=><button key={t} className={`topic-button ${topic===t?"selected":""}`} onClick={()=>setTopic(t)}>{t}<ChevronRight size={15}/></button>)}</div><div className="panel explanation"><span className="eyebrow">SCIENTIST EXPLAINS</span><h3>{topic}</h3><p>{explanation}</p><p className="tiny muted">Level: {level}. Content is introductory and should be expanded with verified scientific references before public deployment.</p><div className="button-row"><button className="btn secondary" onClick={()=>speak(explanation)}><Volume2 size={16}/> Listen</button><button className="btn primary" onClick={askAI}><Sparkles size={16}/> Ask AI</button></div></div><button className="btn primary full" onClick={markComplete}>{completed.includes(module.id)?"Lab completed ✓":"Mark lab as explored"}</button></aside></div></div>;
}

function Quiz({quizIndex,selected,score,quizDone,chooseAnswer,nextQuestion,resetQuiz}) {
  const q=questions[quizIndex];
  return <div className="stack narrow"><PageHeading eyebrow="TEST YOUR CURIOSITY" title="Quiz Arena" description="Try these short science questions. Learn from every answer."/>
    <div className="quiz-card">{quizDone?<div className="quiz-result"><div className="result-icon">🏆</div><span className="eyebrow">MISSION COMPLETE</span><h2>You scored {score} out of {questions.length}</h2><p className="muted">Every question is a chance to learn something new.</p><button className="btn primary" onClick={resetQuiz}>Try again</button></div>:<><div className="quiz-progress"><span>QUESTION {quizIndex+1} OF {questions.length}</span><span>{score} correct so far</span></div><div className="progress-track"><div style={{width:`${((quizIndex+1)/questions.length)*100}%`}}/></div><h2>{q.q}</h2><div className="answer-list">{q.options.map((o,i)=><button key={o} disabled={selected!==null} className={`answer-option ${selected===i?"chosen":""} ${selected!==null&&i===q.answer?"correct":""} ${selected===i&&i!==q.answer?"incorrect":""}`} onClick={()=>chooseAnswer(i)}><span className="answer-letter">{String.fromCharCode(65+i)}</span>{o}</button>)}</div>{selected!==null&&<div className="answer-explanation"><b>{selected===q.answer?"Correct! Well done.":"Let's learn from that."}</b><p>{q.explanation}</p></div>}<button className="btn primary full" disabled={selected===null} onClick={nextQuestion}>{quizIndex===questions.length-1?"See my result":"Next question"}<ChevronRight size={17}/></button></>}</div>
  </div>;
}

function Careers() {
  return <div className="stack"><PageHeading eyebrow="FUTURE PATHWAYS" title="Career Navigator" description="Discover how curiosity in science can connect to different fields of study and work."/><div className="notice"><ShieldCheck size={20}/><span>Career information is introductory. Check official institution and examination websites for current eligibility, admissions and deadlines.</span></div><div className="career-grid">{careers.map((c,i)=><article className="career-card" key={c.title}><div className="career-icon">{["🔭","🚀","🧪","🛰️","🪐","📚"][i]}</div><span className="card-category">{c.area}</span><h3>{c.title}</h3><p>{c.description}</p><div className="career-skills"><span>Science</span><span>Learning</span><span>Problem solving</span></div></article>)}</div><div className="panel resources"><h3>Explore official learning resources</h3><a href="https://spaceplace.nasa.gov/" target="_blank" rel="noreferrer">NASA Space Place ↗</a><a href="https://www.isro.gov.in/" target="_blank" rel="noreferrer">ISRO official website ↗</a><a href="https://www.iist.ac.in/" target="_blank" rel="noreferrer">Indian Institute of Space Science and Technology ↗</a></div></div>;
}

function Progress({completed,setPage}) {
  return <div className="stack"><PageHeading eyebrow="YOUR LEARNING JOURNEY" title="My progress" description="See the learning labs you have explored on this device."/><div className="progress-overview"><div className="progress-ring"><strong>{Math.round(completed.length/modules.length*100)}%</strong><small>Explored</small></div><div><h2>{completed.length} of {modules.length} labs explored</h2><p className="muted">Keep following your curiosity. Your progress is saved in this browser.</p><button className="btn primary" onClick={()=>setPage("explore")}>Continue exploring</button></div></div><div className="panel"><h3>Learning lab checklist</h3>{modules.map(m=><div className="progress-row" key={m.id}><span>{m.icon} {m.title}</span>{completed.includes(m.id)?<span className="status-done"><CheckCircle2 size={16}/> Explored</span>:<span className="status-pending">Not explored yet</span>}</div>)}</div></div>;
}

function SettingsPage({profile,setDark,dark,largeText,setLargeText,logout}) {
  return <div className="stack narrow"><PageHeading eyebrow="PREFERENCES" title="Settings" description="Adjust the experience to make learning comfortable for you."/><div className="panel settings-list"><div className="setting-row"><div><b>Dark appearance</b><small>Use a darker colour theme.</small></div><button className={`toggle ${dark?"on":""}`} onClick={()=>setDark(!dark)} aria-label="Toggle dark appearance"><span/></button></div><div className="setting-row"><div><b>Large text</b><small>Increase text size across the website.</small></div><button className={`toggle ${largeText?"on":""}`} onClick={()=>setLargeText(!largeText)} aria-label="Toggle large text"><span/></button></div><div className="setting-row"><div><b>Explorer profile</b><small>{profile.name} · {profile.classLevel} · {profile.language}</small></div><UserRound/></div><button className="btn secondary full" onClick={logout}><LogOut size={17}/> Log out of this demo profile</button></div><div className="notice"><CircleHelp size={20}/><span>This prototype stores profile and progress information locally in your browser. For production, integrate a secure authentication provider and a privacy policy before collecting user accounts.</span></div></div>;
}

function PageHeading({eyebrow,title,description}) { return <div className="page-heading"><span className="eyebrow">{eyebrow}</span><h1>{title}</h1><p>{description}</p></div>; }
export default App;

export const modules = [
  { id:"solar", title:"Solar System Lab", category:"Astronomy", icon:"☀️", description:"Explore the Sun, planets, moons, orbits, eclipses and seasons.", topics:["The Sun and planets","Rotation and revolution","Moon phases","Eclipses","Comets and asteroids"] },
  { id:"galaxy", title:"Universe & Galaxy Lab", category:"Cosmology", icon:"🌌", description:"Travel through galaxies, nebulae, clusters and the observable universe.", topics:["Big Bang overview","Milky Way","Galaxy types","Nebulae","Cosmic distances"] },
  { id:"stars", title:"Stars & Stellar Evolution", category:"Astrophysics", icon:"✨", description:"Discover how stars form, evolve and reach their final stages.", topics:["Star formation","Main sequence","Red giants","White dwarfs","Supernovae"] },
  { id:"extreme", title:"Extreme Space Phenomena", category:"Astrophysics", icon:"🕳️", description:"Learn about black holes, pulsars, quasars and gravitational waves.", topics:["Black holes","Event horizon","Pulsars","Quasars","Gravitational waves"] },
  { id:"human", title:"Human Space Exploration", category:"Spaceflight", icon:"🧑‍🚀", description:"Explore astronaut life, space stations, habitats and missions.", topics:["International Space Station","Microgravity","Astronaut training","Space habitats","Moon and Mars missions"] },
  { id:"technology", title:"Space Technology Lab", category:"Engineering", icon:"🛰️", description:"Understand rockets, satellites, probes, rovers and communications.", topics:["Rocket stages","Satellites","Space telescopes","Rovers","Remote sensing"] },
  { id:"exo", title:"Exoplanets & Astrobiology", category:"Astrobiology", icon:"🪐", description:"Investigate planets around other stars and conditions for life.", topics:["Exoplanets","Detection methods","Habitable zones","Planetary atmospheres","Astrobiology"] },
  { id:"observe", title:"Astronomy Observation Lab", category:"Observation", icon:"🔭", description:"Discover telescopes, wavelengths, constellations and observation.", topics:["Optical astronomy","Radio astronomy","Infrared astronomy","Constellations","Observatories"] },
  { id:"india", title:"Indian Space Research Lab", category:"India", icon:"🇮🇳", description:"Learn about ISRO, Chandrayaan, Aditya-L1 and Gaganyaan.", topics:["ISRO overview","Chandrayaan","Mangalyaan","Aditya-L1","Gaganyaan"] },
  { id:"cosmos", title:"Advanced Astronomy & Cosmology", category:"Advanced", icon:"🧭", description:"Explore spacetime, relativity, redshift and cosmic expansion.", topics:["Gravity and spacetime","Relativity concepts","Redshift","Cosmic microwave background","Hubble's law"] }
];

export const careers = [
  { title:"Astronomer", area:"Research", description:"Studies stars, planets, galaxies and other objects in space." },
  { title:"Aerospace Engineer", area:"Engineering", description:"Designs and tests aircraft, spacecraft and related systems." },
  { title:"Astrophysicist", area:"Research", description:"Uses physics and mathematics to understand the universe." },
  { title:"Satellite Engineer", area:"Technology", description:"Works on satellite design, testing, communication and operations." },
  { title:"Planetary Scientist", area:"Research", description:"Studies planets, moons, surfaces, atmospheres and planetary history." },
  { title:"Science Communicator", area:"Education", description:"Makes scientific ideas understandable through writing, media and teaching." }
];

export const questions = [
  { q:"Which star is at the centre of our Solar System?", options:["Sirius","The Sun","Polaris","Vega"], answer:1, explanation:"The Sun is the star at the centre of our Solar System. The planets orbit it." },
  { q:"What does a planet's rotation describe?", options:["Its spin on its axis","Its path around a star","Its colour","Its distance from a galaxy"], answer:0, explanation:"Rotation is the spinning of an object around its own axis." },
  { q:"Which organisation is India's national space agency?", options:["NASA","ESA","ISRO","JAXA"], answer:2, explanation:"ISRO is the Indian Space Research Organisation." },
  { q:"What is a galaxy?", options:["A single star","A large collection of stars, gas and dust held by gravity","A type of rocket","A moon"], answer:1, explanation:"A galaxy is a vast system containing stars, gas, dust and dark matter, bound by gravity." },
  { q:"Which instrument collects light from distant objects?", options:["Thermometer","Telescope","Compass","Barometer"], answer:1, explanation:"Telescopes collect and help analyse light from distant astronomical objects." }
];

export const languageNames = ["English","தமிழ்","हिन्दी","తెలుగు","ಕನ್ನಡ","മലയാളം","বাংলা","मराठी","ગુજરાતી","ਪੰਜਾਬੀ","ଓଡ଼ିଆ","অসমীয়া","اردو","संस्कृत"];
